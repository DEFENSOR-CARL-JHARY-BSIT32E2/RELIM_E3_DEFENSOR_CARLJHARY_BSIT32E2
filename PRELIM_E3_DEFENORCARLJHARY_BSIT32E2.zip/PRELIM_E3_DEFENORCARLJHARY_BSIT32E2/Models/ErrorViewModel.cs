namespace PRELIM_E3_DEFENORCARLJHARY_BSIT32E2.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}